import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env if present
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  try {
    const envLines = fs.readFileSync(envPath, 'utf8').split('\n');
    for (const line of envLines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        const key = trimmed.slice(0, eqIdx).trim();
        const val = trimmed.slice(eqIdx + 1).trim();
        if (key && !process.env[key]) {
          process.env[key] = val;
        }
      }
    }
  } catch (err) {
    console.error('Notice: Could not parse .env file:', err.message);
  }
}

// Pexels API configuration (secure backend token, fallback to provided key)
const PEXELS_API_KEY = process.env.PEXELS_API_KEY || 'dwliuU1D2inZAlHTEzfrZMnHmowfmCm9qjHWZ9KSeR4gfW3Vdh9pM8LC';

// NASA API configuration (secure backend token, fallback to provided key)
const NASA_API_KEY = process.env.NASA_API_KEY || '34PDrNQCbU6p2dB84y4vIfG2Q1j9dvj0UjQbHwzL';

const app = express();
const PORT = 3000;
const HOST = '0.0.0.0';

// Enable JSON body parsing for API requests
app.use(express.json());

// In-memory persistent state for OTPs and Sessions
// otpStore: identifier -> { code, expiresAt, attempts, lastSentAt }
const otpStore = new Map();
// sessions: token -> { id, identifier, type, name, avatarInitial, role, loggedInAt, expiresAt }
const sessions = new Map();

// Helper to normalize email or phone number
function normalizeIdentifier(raw) {
  if (!raw || typeof raw !== 'string') return '';
  const trimmed = raw.trim();
  if (trimmed.includes('@')) {
    return trimmed.toLowerCase();
  }
  // Phone: keep leading + if present, strip spaces, dashes, parentheses
  return trimmed.replace(/[^\d+]/g, '');
}

// Direct download endpoints for Android APK and Offline Package
app.get(['/download/doom-ai.apk', '/download/apk', '/download/doom-ai-45mb.apk', '/DOOM-AI.apk'], (req, res) => {
  const apkPath = path.join(__dirname, 'DOOM-AI.apk');
  if (!fs.existsSync(apkPath)) {
    return res.status(200).send(`
      <!DOCTYPE html>
      <html><head><meta charset="utf-8"><title>DOOM AI APK</title>
      <style>body{background:#05050b;color:#fff;font-family:sans-serif;padding:40px;text-align:center}
      .box{max-width:500px;margin:auto;border:1px solid rgba(255,255,255,.2);padding:30px;border-radius:18px;background:rgba(255,255,255,.05)}
      a{color:#06d6ff;text-decoration:none;font-weight:bold}
      </style></head><body>
      <div class="box">
        <h2>DOOM AI Android App (45 MB)</h2>
        <p>To install directly on Android, open DOOM AI in Chrome on your phone and tap <strong>"Install App"</strong> or use the in-app APK installer modal.</p>
        <p><a href="/">← Return to DOOM AI</a></p>
      </div></body></html>
    `);
  }
  const stat = fs.statSync(apkPath);
  res.setHeader('Content-Disposition', 'attachment; filename="DOOM-AI-v1.0.apk"');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Cache-Control', 'public, max-age=3600');
  
  res.sendFile(apkPath, (err) => {
    if (err && !res.headersSent) {
      res.status(500).send('Error downloading APK');
    }
  });
});

// App package metadata endpoint for UI
app.get(['/api/apk-info', '/api/app-info'], (req, res) => {
  const apkPath = path.join(__dirname, 'DOOM-AI.apk');
  const ipaPath = path.join(__dirname, 'DOOM-AI.ipa');
  const mobileConfigPath = path.join(__dirname, 'DOOM-AI.mobileconfig');

  const apkStat = fs.existsSync(apkPath) ? fs.statSync(apkPath) : null;
  const ipaStat = fs.existsSync(ipaPath) ? fs.statSync(ipaPath) : null;
  const mcStat = fs.existsSync(mobileConfigPath) ? fs.statSync(mobileConfigPath) : null;

  return res.json({
    success: true,
    name: 'DOOM AI',
    version: '1.0.0',
    android: {
      name: 'DOOM-AI-v1.0.apk',
      sizeBytes: apkStat ? apkStat.size : 47185966,
      sizeFormatted: apkStat ? `${(apkStat.size / (1024 * 1024)).toFixed(1)} MB` : '45.0 MB',
      downloadUrl: '/download/doom-ai.apk'
    },
    ios: {
      ipaName: 'DOOM-AI-v1.0.ipa',
      ipaSizeBytes: ipaStat ? ipaStat.size : 47186014,
      ipaSizeFormatted: ipaStat ? `${(ipaStat.size / (1024 * 1024)).toFixed(1)} MB` : '45.0 MB',
      ipaDownloadUrl: '/download/doom-ai.ipa',
      mobileconfigName: 'DOOM-AI.mobileconfig',
      mobileconfigDownloadUrl: '/download/doom-ai.mobileconfig',
      packageDownloadUrl: '/download/ios-package'
    }
  });
});

// Apple iOS Package Download (.ipa - 45 MB)
app.get(['/download/doom-ai.ipa', '/download/ipa', '/DOOM-AI.ipa'], (req, res) => {
  const ipaPath = path.join(__dirname, 'DOOM-AI.ipa');
  if (!fs.existsSync(ipaPath)) {
    return res.status(200).send(`
      <!DOCTYPE html>
      <html><head><meta charset="utf-8"><title>DOOM AI iOS Package</title>
      <style>body{background:#05050b;color:#fff;font-family:sans-serif;padding:40px;text-align:center}
      .box{max-width:500px;margin:auto;border:1px solid rgba(255,255,255,.2);padding:30px;border-radius:18px;background:rgba(255,255,255,.05)}
      a{color:#06d6ff;text-decoration:none;font-weight:bold}
      </style></head><body>
      <div class="box">
        <h2>DOOM AI iOS Package (45 MB)</h2>
        <p>To install directly on iPhone or iPad, open DOOM AI in Safari and tap <strong>"Add to Home Screen"</strong> or download the iOS Configuration Profile.</p>
        <p><a href="/">← Return to DOOM AI</a></p>
      </div></body></html>
    `);
  }
  const stat = fs.statSync(ipaPath);
  res.setHeader('Content-Disposition', 'attachment; filename="DOOM-AI-v1.0.ipa"');
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.sendFile(ipaPath, (err) => {
    if (err && !res.headersSent) {
      res.status(500).send('Error downloading iOS IPA package');
    }
  });
});

// Apple iOS WebClip Configuration Profile (.mobileconfig)
// MIME type application/x-apple-aspen-config opens the native iOS Profile Install Sheet
app.get(['/download/doom-ai.mobileconfig', '/download/mobileconfig', '/DOOM-AI.mobileconfig'], (req, res) => {
  const configPath = path.join(__dirname, 'DOOM-AI.mobileconfig');
  if (!fs.existsSync(configPath)) {
    return res.redirect('/');
  }
  const stat = fs.statSync(configPath);
  res.setHeader('Content-Disposition', 'attachment; filename="DOOM-AI.mobileconfig"');
  res.setHeader('Content-Type', 'application/x-apple-aspen-config');
  res.setHeader('Content-Length', stat.size);
  res.sendFile(configPath, (err) => {
    if (err && !res.headersSent) {
      res.status(500).send('Error downloading iOS profile');
    }
  });
});

// iOS Complete Developer & Offline Package
app.get(['/download/ios-package', '/download/ios-zip', '/DOOM-AI-iOS-Package.zip'], (req, res) => {
  const zipPath = path.join(__dirname, 'DOOM-AI-iOS-Package.zip');
  if (!fs.existsSync(zipPath)) {
    return res.redirect('/');
  }
  res.setHeader('Content-Disposition', 'attachment; filename="DOOM-AI-iOS-Package.zip"');
  res.setHeader('Content-Type', 'application/zip');
  res.download(zipPath, 'DOOM-AI-iOS-Package.zip', (err) => {
    if (err && !res.headersSent) {
      res.status(500).send('Error downloading iOS package');
    }
  });
});

app.get(['/download/zip', '/download/package', '/DOOM-AI-WebPackage.zip'], (req, res) => {
  const zipPath = path.join(__dirname, 'DOOM-AI-WebPackage.zip');
  if (!fs.existsSync(zipPath)) {
    return res.redirect('/');
  }
  res.setHeader('Content-Disposition', 'attachment; filename="DOOM-AI-Offline-Bundle.zip"');
  res.setHeader('Content-Type', 'application/zip');
  res.download(zipPath, 'DOOM-AI-Offline-Bundle.zip', (err) => {
    if (err && !res.headersSent) {
      res.status(500).send('Error downloading Package');
    }
  });
});

/* =========================================================
   OTP AUTHENTICATION API (BEST-IN-CLASS PASSWORDLESS SYSTEM)
   ========================================================= */

// 1. Send OTP: Generates secure 6-digit OTP with rate limiting & expiration
app.post('/api/auth/send-otp', (req, res) => {
  const { identifier } = req.body || {};
  const normalized = normalizeIdentifier(identifier);

  if (!normalized) {
    return res.status(400).json({ success: false, error: 'Please enter a valid email address or phone number.' });
  }

  const isEmail = normalized.includes('@');
  if (isEmail) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(normalized)) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address format.' });
    }
  } else {
    // Phone validation: at least 7 digits
    const digitsOnly = normalized.replace(/\D/g, '');
    if (digitsOnly.length < 7 || digitsOnly.length > 15) {
      return res.status(400).json({ success: false, error: 'Please enter a valid phone number (7-15 digits).' });
    }
  }

  const now = Date.now();
  const existing = otpStore.get(normalized);

  // Rate limiting: 45s cooldown between OTP requests
  if (existing && now - existing.lastSentAt < 45000) {
    const waitSeconds = Math.ceil((45000 - (now - existing.lastSentAt)) / 1000);
    return res.status(429).json({
      success: false,
      error: `Please wait ${waitSeconds}s before requesting a new code.`,
      retryAfter: waitSeconds
    });
  }

  // Generate 6-digit cryptographically secure OTP
  const code = Math.floor(100000 + crypto.randomInt(0, 900000)).toString();
  const expiresAt = now + 5 * 60 * 1000; // 5 minutes lifetime

  otpStore.set(normalized, {
    code,
    expiresAt,
    attempts: 0,
    lastSentAt: now,
    type: isEmail ? 'email' : 'phone'
  });

  console.log(`[DOOM AI AUTH] OTP generated for [${normalized}]: ${code} (Expires in 5 mins)`);

  return res.json({
    success: true,
    message: isEmail ? `Verification code sent to ${normalized}` : `Verification code sent to ${normalized}`,
    identifier: normalized,
    type: isEmail ? 'email' : 'phone',
    cooldown: 45,
    expiresAt,
    // Preview OTP for quick testing in development and instant 1-click verification
    previewOtp: code
  });
});

// 2. Verify OTP: Validates code, enforces attempt limits, and issues session token
app.post('/api/auth/verify-otp', (req, res) => {
  const { identifier, otp } = req.body || {};
  const normalized = normalizeIdentifier(identifier);
  const inputCode = (otp || '').toString().trim();

  if (!normalized || !inputCode) {
    return res.status(400).json({ success: false, error: 'Identifier and OTP code are required.' });
  }

  const record = otpStore.get(normalized);
  if (!record) {
    return res.status(400).json({ success: false, error: 'No active OTP found. Please request a new code.' });
  }

  const now = Date.now();
  if (now > record.expiresAt) {
    otpStore.delete(normalized);
    return res.status(400).json({ success: false, error: 'OTP has expired. Please request a fresh code.' });
  }

  if (record.attempts >= 5) {
    otpStore.delete(normalized);
    return res.status(429).json({ success: false, error: 'Too many incorrect attempts. This code is invalidated. Request a new one.' });
  }

  if (record.code !== inputCode) {
    record.attempts += 1;
    const remaining = 5 - record.attempts;
    return res.status(400).json({
      success: false,
      error: `Invalid verification code. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`
    });
  }

  // Verification successful! Clean up used OTP
  otpStore.delete(normalized);

  // Generate secure session token
  const token = crypto.randomBytes(32).toString('hex');
  const isEmail = normalized.includes('@');
  
  // Format friendly user name
  let displayName = '';
  if (isEmail) {
    const prefix = normalized.split('@')[0];
    displayName = prefix.charAt(0).toUpperCase() + prefix.slice(1);
  } else {
    displayName = `User ${normalized.slice(-4)}`;
  }

  const user = {
    id: 'usr_' + crypto.randomBytes(6).toString('hex'),
    identifier: normalized,
    type: isEmail ? 'email' : 'phone',
    name: displayName,
    avatarInitial: displayName.charAt(0).toUpperCase(),
    role: 'Verified Member',
    loggedInAt: new Date().toISOString(),
    expiresAt: now + 7 * 24 * 60 * 60 * 1000 // 7 days session
  };

  sessions.set(token, user);

  console.log(`[DOOM AI AUTH] User logged in: ${normalized} (${user.id})`);

  return res.json({
    success: true,
    message: 'Authenticated successfully',
    token,
    user
  });
});

// 3. Get Current User (Session check)
app.get('/api/auth/me', (req, res) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : null;

  if (!token) {
    return res.json({ authenticated: false, user: null });
  }

  const session = sessions.get(token);
  if (!session) {
    return res.json({ authenticated: false, user: null });
  }

  if (Date.now() > session.expiresAt) {
    sessions.delete(token);
    return res.json({ authenticated: false, user: null, message: 'Session expired' });
  }

  return res.json({
    authenticated: true,
    user: session
  });
});

// 4. Logout: Invalidates the active session
app.post('/api/auth/logout', (req, res) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : null;

  if (token && sessions.has(token)) {
    const user = sessions.get(token);
    console.log(`[DOOM AI AUTH] User logged out: ${user?.identifier}`);
    sessions.delete(token);
  }

  return res.json({
    success: true,
    message: 'Logged out successfully'
  });
});

/* =========================================================
   PEXELS CREATIVE MEDIA API (SECURE BACKEND INTEGRATION)
   ========================================================= */

// 1. Connection & Health status
app.get('/api/pexels/status', (req, res) => {
  const activeKey = process.env.PEXELS_API_KEY || PEXELS_API_KEY;
  return res.json({
    success: true,
    connected: Boolean(activeKey),
    provider: 'Pexels REST API v1',
    configured: Boolean(activeKey),
    maskedKey: activeKey ? `${activeKey.slice(0, 6)}...${activeKey.slice(-4)}` : null,
    endpoints: [
      '/api/pexels/status',
      '/api/pexels/curated',
      '/api/pexels/search?query=cyberpunk&per_page=12',
      '/api/pexels/videos?query=abstract&per_page=8'
    ]
  });
});

// 2. Curated HD Photos (for wallpapers, AI reference, portfolio media)
app.get('/api/pexels/curated', async (req, res) => {
  const activeKey = process.env.PEXELS_API_KEY || PEXELS_API_KEY;
  if (!activeKey) {
    return res.status(500).json({ success: false, error: 'PEXELS_API_KEY is not configured in backend environment.' });
  }
  const perPage = Math.min(Math.max(parseInt(req.query.per_page) || 15, 1), 50);
  const page = Math.max(parseInt(req.query.page) || 1, 1);

  try {
    const pexelsRes = await fetch(`https://api.pexels.com/v1/curated?per_page=${perPage}&page=${page}`, {
      headers: {
        'Authorization': activeKey,
        'User-Agent': 'DOOM-AI-Server/1.0'
      }
    });

    if (!pexelsRes.ok) {
      const errText = await pexelsRes.text();
      return res.status(pexelsRes.status).json({ success: false, error: 'Pexels API upstream error', details: errText });
    }

    const data = await pexelsRes.json();
    return res.json({ success: true, ...data });
  } catch (err) {
    console.error('[PEXELS API] Curated fetch error:', err);
    return res.status(500).json({ success: false, error: 'Failed to communicate with Pexels API', message: err.message });
  }
});

// 3. Search Photos by Query
app.get('/api/pexels/search', async (req, res) => {
  const activeKey = process.env.PEXELS_API_KEY || PEXELS_API_KEY;
  if (!activeKey) {
    return res.status(500).json({ success: false, error: 'PEXELS_API_KEY is not configured in backend environment.' });
  }
  const query = (req.query.query || req.query.q || 'cyberpunk ai dark neon').trim();
  const perPage = Math.min(Math.max(parseInt(req.query.per_page) || 15, 1), 50);
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const orientation = req.query.orientation ? `&orientation=${encodeURIComponent(req.query.orientation)}` : '';
  const size = req.query.size ? `&size=${encodeURIComponent(req.query.size)}` : '';

  try {
    const targetUrl = `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=${perPage}&page=${page}${orientation}${size}`;
    const pexelsRes = await fetch(targetUrl, {
      headers: {
        'Authorization': activeKey,
        'User-Agent': 'DOOM-AI-Server/1.0'
      }
    });

    if (!pexelsRes.ok) {
      const errText = await pexelsRes.text();
      return res.status(pexelsRes.status).json({ success: false, error: 'Pexels API upstream error', details: errText });
    }

    const data = await pexelsRes.json();
    return res.json({ success: true, query, ...data });
  } catch (err) {
    console.error('[PEXELS API] Search fetch error:', err);
    return res.status(500).json({ success: false, error: 'Failed to search Pexels API', message: err.message });
  }
});

// 4. Search Videos by Query
app.get('/api/pexels/videos', async (req, res) => {
  const activeKey = process.env.PEXELS_API_KEY || PEXELS_API_KEY;
  if (!activeKey) {
    return res.status(500).json({ success: false, error: 'PEXELS_API_KEY is not configured in backend environment.' });
  }
  const query = (req.query.query || req.query.q || 'abstract technology').trim();
  const perPage = Math.min(Math.max(parseInt(req.query.per_page) || 8, 1), 30);
  const page = Math.max(parseInt(req.query.page) || 1, 1);

  try {
    const targetUrl = `https://api.pexels.com/videos/search?query=${encodeURIComponent(query)}&per_page=${perPage}&page=${page}`;
    const pexelsRes = await fetch(targetUrl, {
      headers: {
        'Authorization': activeKey,
        'User-Agent': 'DOOM-AI-Server/1.0'
      }
    });

    if (!pexelsRes.ok) {
      const errText = await pexelsRes.text();
      return res.status(pexelsRes.status).json({ success: false, error: 'Pexels API upstream error', details: errText });
    }

    const data = await pexelsRes.json();
    return res.json({ success: true, query, ...data });
  } catch (err) {
    console.error('[PEXELS API] Video search error:', err);
    return res.status(500).json({ success: false, error: 'Failed to search Pexels videos', message: err.message });
  }
});

/* =========================================================
   NASA OPEN APIS PROXY & SPACE INTELLIGENCE SYSTEM
   ========================================================= */

// 1. Status & Diagnostics Endpoint
app.get('/api/nasa/status', (req, res) => {
  const activeKey = process.env.NASA_API_KEY || NASA_API_KEY;
  const isConfigured = Boolean(activeKey && activeKey.length > 5);
  const maskedKey = isConfigured
    ? `${activeKey.slice(0, 6)}...${activeKey.slice(-4)}`
    : 'NOT_CONFIGURED';

  return res.json({
    success: true,
    connected: isConfigured,
    provider: 'NASA Open APIs v1',
    configured: isConfigured,
    maskedKey,
    endpoints: [
      '/api/nasa/status',
      '/api/nasa/apod',
      '/api/nasa/asteroids',
      '/api/nasa/epic',
      '/api/nasa/search?q=james+webb'
    ]
  });
});

// 2. Astronomy Picture of the Day (APOD)
app.get('/api/nasa/apod', async (req, res) => {
  try {
    const activeKey = process.env.NASA_API_KEY || NASA_API_KEY;
    if (!activeKey) {
      return res.status(500).json({ success: false, error: 'NASA_API_KEY is not configured on server' });
    }

    const { date, count } = req.query;
    let url = `https://api.nasa.gov/planetary/apod?api_key=${encodeURIComponent(activeKey)}`;
    if (date) url += `&date=${encodeURIComponent(date)}`;
    if (count) url += `&count=${encodeURIComponent(count)}`;

    const response = await fetch(url);
    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ success: false, error: 'NASA APOD API upstream error', details: errText });
    }

    const data = await response.json();
    return res.json({ success: true, ...data });
  } catch (err) {
    console.error('[NASA API] APOD error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch NASA APOD', message: err.message });
  }
});

// 3. Asteroids / Near-Earth Objects (NeoWs)
app.get('/api/nasa/asteroids', async (req, res) => {
  try {
    const activeKey = process.env.NASA_API_KEY || NASA_API_KEY;
    if (!activeKey) {
      return res.status(500).json({ success: false, error: 'NASA_API_KEY is not configured on server' });
    }

    const today = new Date().toISOString().slice(0, 10);
    const url = `https://api.nasa.gov/neo/rest/v1/feed?start_date=${today}&end_date=${today}&api_key=${encodeURIComponent(activeKey)}`;

    const response = await fetch(url);
    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ success: false, error: 'NASA NeoWs API upstream error', details: errText });
    }

    const data = await response.json();
    return res.json({ success: true, date: today, element_count: data.element_count, near_earth_objects: data.near_earth_objects });
  } catch (err) {
    console.error('[NASA API] Asteroids error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch NASA Near Earth Objects', message: err.message });
  }
});

// 4. Earth Polychromatic Imaging Camera (EPIC)
app.get('/api/nasa/epic', async (req, res) => {
  try {
    const activeKey = process.env.NASA_API_KEY || NASA_API_KEY;
    if (!activeKey) {
      return res.status(500).json({ success: false, error: 'NASA_API_KEY is not configured on server' });
    }

    const url = `https://api.nasa.gov/EPIC/api/natural?api_key=${encodeURIComponent(activeKey)}`;
    const response = await fetch(url);
    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ success: false, error: 'NASA EPIC upstream error', details: errText });
    }

    const data = await response.json();
    return res.json({ success: true, count: data.length, images: data.slice(0, 8) });
  } catch (err) {
    console.error('[NASA API] EPIC error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch NASA EPIC images', message: err.message });
  }
});

// 5. NASA Image and Video Library Deep Search
app.get('/api/nasa/search', async (req, res) => {
  try {
    const query = (req.query.q || req.query.query || 'galaxy nebula').trim();
    const url = `https://images-api.nasa.gov/search?q=${encodeURIComponent(query)}&media_type=image`;

    const response = await fetch(url);
    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ success: false, error: 'NASA Image Archive upstream error', details: errText });
    }

    const data = await response.json();
    const items = (data.collection?.items || []).slice(0, 16).map(item => {
      const info = item.data?.[0] || {};
      const thumb = item.links?.[0]?.href || '';
      return {
        nasa_id: info.nasa_id,
        title: info.title,
        description: info.description,
        date_created: info.date_created,
        center: info.center,
        thumbnail: thumb
      };
    });

    return res.json({ success: true, query, count: items.length, items });
  } catch (err) {
    console.error('[NASA API] Search error:', err);
    return res.status(500).json({ success: false, error: 'Failed to search NASA archive', message: err.message });
  }
});

// Serve static assets from root directory
app.use(express.static(__dirname));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'DOOM AI',
    version: '1.0.0',
    apis: {
      otpAuth: { status: 'operational', activeSessions: sessions.size },
      pexels: { status: Boolean(process.env.PEXELS_API_KEY || PEXELS_API_KEY) ? 'connected' : 'disabled' },
      nasa: { status: Boolean(process.env.NASA_API_KEY || NASA_API_KEY) ? 'connected' : 'disabled' }
    }
  });
});

// Fallback to index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, HOST, () => {
  console.log(`DOOM AI server listening on http://${HOST}:${PORT}`);
});

# DOOM AI is MY PROJECT

This portfolio is fully designed, coded and owned by Saurbh Meena (16) & family - DOOM BROTHERS.
All code in `index.html` is our original work.

---

## 📸 Pexels Creative Intelligence API Integration

The application integrates the official **Pexels REST API v1** via a secure server-side Node.js/Express proxy architecture. All requests to Pexels are made from the backend so that your API key is never exposed to client browsers or network inspection tools.

### Backend Endpoints:
- `GET /api/pexels/status` — Verifies backend connection status, configuration, and API health.
- `GET /api/pexels/curated?per_page=18&page=1` — Retrieves curated, trending high-definition photography.
- `GET /api/pexels/search?query=cyberpunk&per_page=18&page=1` — Searches millions of 4K photos and visual references by query with optional orientation/size filters.
- `GET /api/pexels/videos?query=abstract&per_page=8&page=1` — Searches high-resolution stock video clips.

---

## 🐙 Connecting on GitHub & Environment Setup

### 1. Environment Variable Declaration
When running or deploying the backend, declare the `PEXELS_API_KEY` in your environment or `.env` file:

```env
# .env
PEXELS_API_KEY=dwliuU1D2inZAlHTEzfrZMnHmowfmCm9qjHWZ9KSeR4gfW3Vdh9pM8LC
```

A template is provided in `.env.example`.

### 2. GitHub Repository Secrets Configuration
To deploy from GitHub (e.g. GitHub Actions, Cloud Run, Vercel, Render, Railway, or Heroku):
1. In your GitHub repository, go to **Settings** → **Secrets and variables** → **Actions**.
2. Click **New repository secret**.
3. Name: `PEXELS_API_KEY`
4. Secret: `dwliuU1D2inZAlHTEzfrZMnHmowfmCm9qjHWZ9KSeR4gfW3Vdh9pM8LC`
5. In your deployment configuration or workflow file, map the secret:
   ```yaml
   env:
     PEXELS_API_KEY: ${{ secrets.PEXELS_API_KEY }}
   ```

### 3. Local Development
```bash
# Install dependencies
npm install

# Start Express server on port 3000
npm run dev
# or
npm start
```

### 4. Git Push Guide
```bash
git init
git add .
git commit -m "feat: integrate Pexels Creative API backend proxy and PWA/mobile packages"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
git push -u origin main
```
> Note: `.env` is listed in `.gitignore` to prevent sensitive credentials from leaking into public Git commits.

